<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-media-files']['version'] = '1.4.4';
